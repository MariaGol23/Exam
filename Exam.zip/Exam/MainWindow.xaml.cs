﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exam
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public string strLoginUsers;
        public string strPasswordUsers;

        private void EnterBt_Click(object sender, RoutedEventArgs e)
        {
            Model.LombardEntities yourbookEntities = Controllers.DBConnection.GetContext();
            strPasswordUsers = PasswordBx.Password;
            strLoginUsers = LoginBx.Text;
            if (!string.IsNullOrEmpty(strLoginUsers) && !string.IsNullOrEmpty(strPasswordUsers))
            {
                var findUsersAccount = yourbookEntities.Employee.Where(x => x.Login == strLoginUsers && x.Password == strPasswordUsers).FirstOrDefault();
                if (findUsersAccount != null)
                {


                    View.Window1 Window = new View.Window1();
                    Window.Show();
                    this.Close();
                    MessageBox.Show("Вход выполнен");
                }
                else
                {
                    var log = yourbookEntities.Employee.Where(x => x.Login == strLoginUsers).FirstOrDefault();
                    var psw = yourbookEntities.Employee.Where(x => x.Password == strPasswordUsers).FirstOrDefault();

                    if (log == null)
                    {
                        MessageBox.Show("Неверный логин");
                    }
                    if (psw == null)
                    {
                        MessageBox.Show("Неверный пароль");
                    }
                }
            }
            else
            {
                MessageBox.Show("Введите все данные");
            }
        }

        private void CancelBt_Click(object sender, RoutedEventArgs e)
        {
            LoginBx.Clear();
            PasswordBx.Clear();
        }
    }

    }

