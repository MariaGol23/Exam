﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.Controllers
{
    class DBConnection
    {
        public static Model.LombardEntities construction_CompanyEntities;

        public static Model.LombardEntities GetContext()
        {
            if (construction_CompanyEntities == null)
            {
                construction_CompanyEntities = new Model.LombardEntities();
            }
            return construction_CompanyEntities;
        }
    }
}
